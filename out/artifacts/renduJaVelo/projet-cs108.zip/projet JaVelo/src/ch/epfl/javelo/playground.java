package ch.epfl.javelo;

public class playground
{
    public static void main(String[] args) {
        System.out.println(Integer.toBinaryString((int)(Math.pow(2,30)-1)));
        System.out.println(Integer.toBinaryString((int)(Math.pow(2,31)-1)));
        System.out.println("0123456789abcdef0123456789abcdef");

    }

}
